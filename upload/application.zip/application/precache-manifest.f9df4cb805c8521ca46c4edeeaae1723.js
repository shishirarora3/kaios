self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4732d61669b892bbc9893f9794b982f0",
    "url": "/index.html"
  },
  {
    "revision": "b8ac112e337f5fe128ec",
    "url": "/static/css/main.e83a6f1a.css"
  },
  {
    "revision": "b8ac112e337f5fe128ec",
    "url": "/static/js/main.d342f2fa.js"
  },
  {
    "revision": "7e8661572dbf62ca66d7837115f59618",
    "url": "/static/js/main.d342f2fa.js.LICENSE.txt"
  },
  {
    "revision": "23d6e35ba1ef3df0e0a8b38d1082e33b",
    "url": "/static/media/focused.23d6e35b.svg"
  },
  {
    "revision": "494c21d725bceddc848723df471ec207",
    "url": "/static/media/focusedVoice.494c21d7.svg"
  },
  {
    "revision": "3353a7b6918630d6195df8d0f9e1342e",
    "url": "/static/media/icon01.3353a7b6.svg"
  },
  {
    "revision": "d682ce59dbc1131324940af4b9e8e78f",
    "url": "/static/media/icon02.d682ce59.svg"
  },
  {
    "revision": "a4f740773ea66400f2ee36e755f3b37d",
    "url": "/static/media/icon03.a4f74077.svg"
  },
  {
    "revision": "ce9e8a6231c57c0262e56ab195a5333f",
    "url": "/static/media/icon04.ce9e8a62.svg"
  },
  {
    "revision": "109d61bf0be7edfa4460e5ccf5737638",
    "url": "/static/media/icon05.109d61bf.svg"
  },
  {
    "revision": "e108a53d584b328c34af9ab0a92e12c5",
    "url": "/static/media/icon06.e108a53d.svg"
  },
  {
    "revision": "44ec56501794cd58a618c52c23f190a1",
    "url": "/static/media/icon07.44ec5650.svg"
  },
  {
    "revision": "7f06a9f87532933b76f3d455490e2b53",
    "url": "/static/media/icon09.7f06a9f8.svg"
  },
  {
    "revision": "ef98637a4d4ecc6125da91f28cc446d7",
    "url": "/static/media/imageForNotification.ef98637a.svg"
  },
  {
    "revision": "cf009122b95774f4325f3e5dbf87d6cd",
    "url": "/static/media/imageForNotification2.cf009122.svg"
  },
  {
    "revision": "07127065df308060d7243d0d914b0819",
    "url": "/static/media/kai-icons.07127065.svg"
  },
  {
    "revision": "4e2f66190ab901acc056c5aa6d1cac58",
    "url": "/static/media/kai-icons.4e2f6619.woff"
  },
  {
    "revision": "5a1c5c18aca6765abadea46336312509",
    "url": "/static/media/kai-icons.5a1c5c18.ttf"
  },
  {
    "revision": "686d74dfef715329736523da67a68ce0",
    "url": "/static/media/kai-icons.686d74df.eot"
  },
  {
    "revision": "6b646cda7acb570b90019984d622671f",
    "url": "/static/media/unFocused.6b646cda.svg"
  },
  {
    "revision": "4274525a66f9aa79cc5f737f4a3d4e1e",
    "url": "/static/media/unFocusedVoice.4274525a.svg"
  }
]);